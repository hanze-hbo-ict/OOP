package gameoflife.exception;

public class LifeException extends Exception {

	public LifeException(String message) {
		super(message);
	}

}
