# Condities en lussen
