/* *****************************************************************************
 *  Name:
 *  NetID:
 *  Precept:
 **************************************************************************** */

Programming Assignment 2: N-Body Simulation


Please estimate the number of hours to complete this assignment:



/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else? If so, please list their names.  ("A Sunday lab TA"
 *  or "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

Yes or no?



/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/


