import java.util.ArrayList;

public class Ball {

    public static void main(String[] args) {}
}
